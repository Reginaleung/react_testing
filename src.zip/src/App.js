﻿import React from 'react';
import Topbar from './components/topbar';
import Data from './components/data';
import { Route, BrowserRouter as Router, Link} from 'react-router-dom';
function App() {
    return (
       <Router> <div id='app'>
            <Topbar />   
            <Link to="/Data">Data</Link>
        </div>
        
            <Route path='/Data' />
            <Data />
        </Router>


            
    )
}

export default App



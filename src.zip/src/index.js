import React, { Component} from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Alert from 'react-bootstrap/Alert'
import reportWebVitals from './reportWebVitals';

/*reactdom.render(
  <react.strictmode>
    <app />
  </react.strictmode>,
  document.getelementbyid('root')
);

// if you want to start measuring performance in your app, pass a function
// to log results (for example: reportwebvitals(console.log))
// or send to an analytics endpoint. learn more: https://bit.ly/cra-vitals
reportwebvitals();*/


ReactDOM.render(<App />, document.getElementById('root'))